<script setup lang="ts">
import FentanylApp from './components/FentanylApp.vue'
</script>

<template>
  <FentanylApp />
</template>

<style>
/* 全局样式 */
</style>
